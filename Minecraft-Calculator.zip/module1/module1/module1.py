from secrets import SystemRandom
from PyQt6.QtWidgets import QProgressBar

class Ore:
    Coal = 1
    Diamond = 1
    Emerald = 1
    Iron = 1
    Copper = "Copper"
    Gold = 1
    Nether_Gold = "Nether Gold"
    Nether_Quartz = 1
    Lapis = "Lapis"
    Amethyst = 4

class FortuneOre:
    def __init__(self, level:float, ore:Ore):
        self.ore = ore
        self.level = level

    def calculate(self, number:int, progressbar:QProgressBar):
        orelist = []
        multiplier = (float(1) / (self.level + float(2))) + ((self.level + float(1)) / float(2))
        for i in range(number):
            progressbar.setValue((i / number) * 100)
            if isinstance(self.ore, str):
                if self.ore == "Copper":
                    self.ore = SystemRandom().randint(2, 3)
                elif self.ore == "Nether Gold":
                    self.ore = SystemRandom().randint(2, 6)
                elif self.ore == "Lapis":
                    self.ore = SystemRandom().randint(4, 9)
            orelist.append(float(self.ore) * float(multiplier))
        progressbar.setValue(100)
        return str(int(float(sum(orelist)) / float(len(orelist))))